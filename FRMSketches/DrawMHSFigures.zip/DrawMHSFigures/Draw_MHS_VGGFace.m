% compare with other methods
clc;clear all;close all;

colorset = [0  0   0;
           160 32 240;
           0  255 255;
           56 94  15;
           255 0 255;
           255 97 0;
           128 42 42;
           0 199 140;
           0 0 255];
colorset = colorset./255;       
markerset = {'-+','-<','-*','-o','-x','-s','-d','-p','->'};

load('Draw_MHS_VGGFace.mat');

indexnums = [1:50];
showindex = [1:50];
plot(indexnums(showindex),drawResult_PL_AS(showindex),'-','Color',colorset(1,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_FL_FC(showindex),'-','Color',colorset(2,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_SL_SR(showindex),'-','Color',colorset(3,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_SL_PR(showindex),'-','Color',colorset(4,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_SL_TSVM(showindex),'-','Color',colorset(5,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_SL_OSVM(showindex),'-','Color',colorset(6,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_RL_HR(showindex),'-','Color',colorset(7,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_RL_BC(showindex),'-','Color',colorset(8,:),'LineWidth',3);

%%

hold on, plot(indexnums(showindex),drawResult_DL_MV(showindex),'-','Color',colorset(9,:),'LineWidth',3);

%%
axis([1 50 0.6 1]);
xlabel('Rank');ylabel('Accuracy');
h=legend('PL-AS','FL-FC','SL-SR','SL-PR','SL-TSVM','SL-OSVM','RL-HR','RL-BC','DL-MV',4);
xlabel('Rank','fontsize',16);
ylabel('Accuracy','fontsize',16);
set(gca,'FontSize', 12);
set(gcf,'unit','normalized','position',[0.1,0.1,0.3,0.4]);



